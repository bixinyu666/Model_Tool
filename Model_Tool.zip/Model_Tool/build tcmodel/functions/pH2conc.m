function conc = pH2conc(pH)
% calculates pH from concentration

conc = 10^(-1*pH);

end