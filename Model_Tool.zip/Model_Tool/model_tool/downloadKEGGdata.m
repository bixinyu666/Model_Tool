function downloadKEGGdata(keggID)
base      = 'http://rest.kegg.jp/';
operation = 'list/';
gene_list = urlread([base operation keggID]);
gene_list = regexpi(gene_list, '[^\n]+','match')'; 
gene_id   = regexpi(gene_list,['(?<=' keggID ':)\S+'],'match');
% Retrieve information for every gene in the list (with a maximum of 10,000
% to avoid bulk downloads)
operation = 'get/';
for i = 1:min([numel(gene_id),10000])
    try
        gene = urlread([base operation keggID ':' gene_id{i}{1}]);
        fid  = fopen(['../model_tool/KEGG/' gene_id{i}{1} '.txt'],'w');
        fprintf(fid,'%s',gene);
        fclose(fid);
        disp(['Downloading KEGG data for ' gene_id{i}{1}])
    catch    
       disp(['Cannot find ' gene_id{i}{1} ' in KEGG']);
       msgbox('your web is unstable, please check it!');
       break
    end
end

end
