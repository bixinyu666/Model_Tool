
function [kcat,origin,matches] = mainMatch(EC,subs,BRENDA,model,i)
%Matching function prioritizing organism and substrate specificity when available.

origin = 0;
%First try to match organism and substrate:
[kcat,matches] = matchKcat(EC,subs,BRENDA,true,true,model,i);
if matches > 0
    origin = 1;

%If no match, try any organism but match the substrate:
else
    [kcat,matches] = matchKcat(EC,subs,BRENDA,false,true,model,i);
    if matches > 0
        origin = 2;
    
    %If no match, try to match organism but with any substrate:
    else
        [kcat,matches] = matchKcat(EC,subs,BRENDA,true,false,model,i);
        if matches > 0
            origin = 3;
    
        %If no match, try any organism and any substrate:
        else
            [kcat,matches] = matchKcat(EC,subs,BRENDA,false,false,model,i);
            if matches > 0
                origin = 4;
            end
        end
    end
end

end
