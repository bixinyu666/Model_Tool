function [dir,tot] = iterativeMatch(EC,subs,i,j,BRENDA,dir,tot,model)
%Will iteratively try to match the EC number to some registry in BRENDA,
%using each time one additional wildcard.

EC      = strsplit(EC,' ');
kcat    = zeros(size(EC));
origin  = zeros(size(EC));
matches = zeros(size(EC));
wc_num  = ones(size(EC)).*1000;
for k = 1:length(EC)
    success  = false;
    while ~success
        %Atempt match:
        [kcat(k),origin(k),matches(k)] = mainMatch(EC{k},subs,BRENDA,model,i);
        %If any match found, ends. If not, introduces one extra wild card and
        %tries again:
        if origin(k) > 0
            success   = true;
            wc_num(k) = sum(EC{k}=='-');
        else
            dot_pos  = [2 strfind(EC{k},'.')];
            wild_num = sum(EC{k}=='-');
            wc_text  = '-.-.-.-';
            EC{k}    = [EC{k}(1:dot_pos(4-wild_num)) wc_text(1:2*wild_num+1)];
        end
    end
end

if sum(origin) > 0
    %For more than one EC: Choose the maximum value among the ones with the
    %less amount of wildcards and the better origin:
    best_pos   = (wc_num == min(wc_num));
    new_origin = origin(best_pos);
    best_pos   = (origin == min(new_origin(new_origin~=0)));
    max_pos    = find(kcat == max(kcat(best_pos)));
    wc_num     = wc_num(max_pos(1));
    origin     = origin(max_pos(1));
    matches    = matches(max_pos(1));
    kcat       = kcat(max_pos(1));
    
    %Update dir and tot:
    dir.kcats(i,j)   = kcat;
    dir.org_s(i,j)   = matches*(origin == 1);
    dir.rest_s(i,j)  = matches*(origin == 2);
    dir.org_ns(i,j)  = matches*(origin == 3);
    dir.rest_ns(i,j) = matches*(origin == 4);
    dir.org_sa(i,j)  = matches*(origin == 5);
    dir.rest_sa(i,j) = matches*(origin == 6);
    tot.org_s        = tot.org_s   + (origin == 1);
    tot.rest_s       = tot.rest_s  + (origin == 2);
    tot.org_ns       = tot.org_ns  + (origin == 3);
    tot.rest_ns      = tot.rest_ns + (origin == 4);
    tot.org_sa       = tot.org_sa  + (origin == 5);
    tot.rest_sa      = tot.rest_sa + (origin == 6);
    tot.wc0          = tot.wc0     + (wc_num == 0);
    tot.wc1          = tot.wc1     + (wc_num == 1);
    tot.wc2          = tot.wc2     + (wc_num == 2);
    tot.wc3          = tot.wc3     + (wc_num == 3);
    tot.wc4          = tot.wc4     + (wc_num == 4);
    tot.queries      = tot.queries + 1;
    tot.matrix(origin,wc_num+1) = tot.matrix(origin,wc_num+1) + 1;
end

end