function varargout = Model_Tool(varargin)
% MODEL_TOOL MATLAB code for Model_Tool.fig
%      MODEL_TOOL, by itself, creates a new MODEL_TOOL or raises the existing
%      singleton*.
%
%      H = MODEL_TOOL returns the handle to a new MODEL_TOOL or the handle to
%      the existing singleton*.
%
%      MODEL_TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MODEL_TOOL.M with the given input arguments.
%
%      MODEL_TOOL('Property','Value',...) creates a new MODEL_TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Model_Tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Model_Tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Model_Tool

% Last Modified by GUIDE v2.5 13-Dec-2021 14:52:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Model_Tool_OpeningFcn, ...
                   'gui_OutputFcn',  @Model_Tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Model_Tool is made visible.
function Model_Tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Model_Tool (see VARARGIN)

% Choose default command line output for Model_Tool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Model_Tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Model_Tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
global str
str=get(handles.edit1,'String');
disp(str);
load keggid.mat;
if sum(strcmp(str,keggid(:,1)))==0
msgbox('input wrong KeggID, please verify it!');
else
msgbox('KeggID Inputed successfully');
msgbox('start download KEGG data, please wait a moment')
downloadKEGGdata(str);
msgbox('KEGG data downloaded successfully,please proceed to the next step!');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
global str
msgbox('please input uniprot.tab');
[filename filepath]=uigetfile('*.tab','input uniprot.tab');
if filename == 0
return
end
file = fullfile(filepath,filename);
updateDatabases('bsu',file);
msgbox('probDatabase download successfully,please proceed to the next step!');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
global model1
[filename filepath]=uigetfile('*.xlsx','input model');
if filename == 0
return
end
str = fullfile(filepath,filename);
model1 = xls2model(str);
model1 = ravenCobraWrapper(model1);
msgbox('Model entered successfully,please proceed to the next step!');


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
global model1
global ecmodel
msgbox('please input protDatabase.mat');
[filename filepath]=uigetfile('*.mat','protDatabase.mat');
if filename == 0
return
end
protDatabase = fullfile(filepath,filename);
model_data = getEnzymeCodes(model1,protDatabase);
msgbox('please input strains_max_kCATs.txt');
[filename filepath]=uigetfile('*.txt','input strains_max_kCATs.txt');
if filename == 0
return
end
file2 = fullfile(filepath,filename);
kcats = matchKcats(model_data,file2);
msgbox('model_data entered successfully');
ecmodel = readKcatData(model_data,kcats)
msgbox('ecModel reconstructed successfully');
save('ecmodel.mat','ecmodel');
msgbox('ecmodel.mat saved in ..\model_tool');


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
msgbox('please enter the path of cplex solver!')
cplexPath = [];
while isempty(cplexPath)
    cplexPath = get(handles.edit2,'String');
end
addpath(genpath(cplexPath))
[path_found,~] = which('cplex');
ret = ~isempty(path_found);
msgbox('cplex_loaded successfully,please proceed to the next step!');



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
global model2
msgbox('please input model');
[filename filepath]=uigetfile('*.xlsx','input model');
if filename == 0
return
end
str = fullfile(filepath,filename);
model2 = xls2model(str);
model2 = ravenCobraWrapper(model2);
msgbox('Model entered successfully');
load('CompartmentData.mat');
model2.CompartmentData = CompartmentData;
msgbox('input model metKEGGID');
[filename filepath]=uigetfile('*.xlsx','input model metKEGGID');
[~,~,data]=xlsread(filename,'sheet1');
load('metSEEDID.mat');
for i=1:length(data)
    if sum(strcmp(data(i,1),metSEEDID(:,1)))>0
         r=find(strcmp(data(i,1),metSEEDID(:,1)));
      data{i,2}=metSEEDID{r(1),2};
    else
        data{i,2}='NA';
    end
     if sum(strcmp(data(i,1),metSEEDID(:,2)))>0
         r=find(strcmp(data(i,1),metSEEDID(:,2)));
      data{i,2}=metSEEDID{r(1),2};
    end
end
model2.metSEEDID = data(:,2);
model2.description = 'tcmodel';
for i = 1:length(model2.metComps)
    if model2.metComps(i,1)==1
        model2.metCompSymbol{i,1}='c'
    else
        model2.metCompSymbol{i,1}='e'
    end    
end
msgbox('model modification completed,please proceed to the next step!');


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
global model2
global tcmodel
tmp = load('thermo_data.mat');
ReactionDB = tmp.ReactionDB;
msgbox('ReactionDB entered successfully');
prepped_m = prepModelforTFA(model2,ReactionDB,model2.CompartmentData);
changeCobraSolver('gurobi')
solFBA = optimizeCbModel(model2);
min_obj = roundsd(0.5*solFBA.f, 2, 'floor');
model2.lb(model2.c==1) = min_obj;
tcmodel = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj);
msgbox('tcmodel reconstructed successfully');
model2xls(tcmodel,'tcmodel.xlsx');
msgbox('ecmodel.xlsx saved in ..\model_tool');


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
global model3
global expressionid
global expression
global targets
global regulator
msgbox('please input expression database')
[filename filepath]=uigetfile('*.xlsx','input expression database');
[~,~,data1]=xlsread(filename,'sheet1');
[~,~,data2]=xlsread(filename,'sheet2');
data1(1,:)=[];
expressionid=data1(:,1);
data1(:,1)=[];
expression=data1;
expression=cell2mat(expression);
data2(1,:)=[];
targets=data2(:,1);
regulator=data2(:,2);
msgbox('expression data entered successfully');
msgbox('please input model');
[filename filepath]=uigetfile('*.xlsx','input model');
if filename == 0
return
end
str2 = fullfile(filepath,filename);
model3 = xls2model(str2);
data=model3.rules;
model3=ravenCobraWrapper(model3);
model3.rules=data;
msgbox('Data import is completed,please proceed to the next step!');


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
global model3
global expressionid
global expression
global targets
global regulator
msgbox('hold on,Preparing the Gurobi solver');
changeCobraSolver('gurobi');
msgbox('Gurobi successfully called');
msgbox('Flux after transcribed perturbation is being calculated');
 f_ko = promv2(model3,expression,expressionid,regulator,targets);
 [v11,v12,Vmin,Vmax] = fluxVariability(model3);
 [f,f_ko,v,v_ko,status1,lostxns,probtfgene] =  promv2(model3,expression,expressionid,regulator,targets,[],[],[],v11,v12,[],[],[]);
msgbox('Flux after transcribed perturbation is calculated');
 xlswrite('f_TFKO.xlsx',f_ko,'sheetl');
 xlswrite('probtfgene.xlsx',probtfgene,'sheet1');
msgbox('flux of TF_KO(f_TFKO,probtfgene) save as xlsx in ...\model_tool');


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
[filename filepath]=uigetfile('*.xlsx','input model');
msgbox('Input your model')
if filename == 0
    return
end
str3 = fullfile(filepath,filename);
model4 = xls2model(str3);
changeCobraSolver('gurobi');
str4 = get(handles.edit3,'String');
model4 = changeObjective(model4,str4);
str5 = get(handles.edit4,'String');
str6 = get(handles.edit5,'String');
if contains(str5,',')
    data2= split(str5,',');
end
if contains(str6,',')
    data3= split(str6,',');
end
for i = 1:length(data3)
    if str2num(data3{i}) > 0
        msgbox('the input reaction lower bound should enter Negative values,please reenter');
    else
        model4 = changeRxnBounds(model4,data2{i},str2num(data3{i}),'l');
        printConstraints(model4,-1000,1000);
        FBAsolution=optimizeCbModel(model4);
        solution = FBAsolution.f;
        solution = num2str(solution);
        msgbox(['the FBAsolution is',solution]);
        data4 = FBAsolution.v
        xlswrite('FBAsolution.xlsx',data4,'sheet1');
        msgbox('FBAsolution.xlsx save in ..\model_tool');
    end
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
[filename filepath]=uigetfile('*.xlsx','input model');
msgbox('Input your model')
if filename == 0
return
end
str = fullfile(filepath,filename);
model5 = xls2model(str);
changeCobraSolver('gurobi');
msgbox('hold on, FVA in progress ')
[minFlux, maxFlux, Vmin, Vmax] = fluxVariability(model5)
xlswrite('FVA.xlsx',minFlux,'minFlux');
xlswrite('FVA.xlsx',maxFlux,'maxFlux');
msgbox('FVA save as xlsx in ...\model_tool')



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
