
function [kcat,matches] = matchKcat(EC,subs,BRENDA,organism,substrate,model,i)
%Will go through BRENDA and will record any match. Afterwards, it will
%return the average value and the number of matches attained.

kcat    = [];
matches = 0;

if organism
    pos = 3;
else
    pos = 4;
end

%Relaxes matching if wild cards are present:
wild     = false;
wild_pos = strfind(EC,'-');
if ~isempty(wild_pos)
    EC  = EC(1:wild_pos(1)-1);
    wild = true;
end

for k = 1:length(BRENDA)
    if strcmpi(EC,BRENDA{k,1}) || (wild && ~isempty(strfind(BRENDA{k,1},EC)))
        if substrate
            %Match substrate name:
            for l = 1:length(subs)
                j = boolean(strcmpi(model.metNames,subs{l}).*(model.S(:,i)~=0));
                if ~isempty(subs{l}) && strcmpi(subs{l},BRENDA{k,2})
                    if BRENDA{k,pos} > 0
                        kcat    = [kcat;BRENDA{k,pos}/abs(model.S(j,i))];
                        matches = matches + 1;
                    end
                end
            end
        elseif BRENDA{k,pos} > 0
            %Match with any substrate:
            kcat    = [kcat;BRENDA{k,pos}];
            matches = matches + 1;
        end
    end
end

%Return maximum value:
if isempty(kcat)
    kcat = 0;
else
    kcat = max(kcat);
end

end