Model_Tool
Requirements
The scripts were developed with Matlab 2015b, Cobra Tool 2.13.3, gurobi 9.5.0 and CPLEX 7.0 (free download for IBM Academic plans) and run successfully on several other versions.

License
The software in this repository is put under a GPLv3.0 licensing scheme - please see the LICENSE file for more details.

This software uses open source components. These are included in the ext/ folder. See the NOTICE for more information on their specific licensing schemes